import React, { useState } from 'react';
import { X, LogOut, ShieldCheck, Mail, Lock, User as UserIcon, CheckCircle2, Sparkles } from 'lucide-react';
import { UserProfile, LanguageCode } from '../types';
import { translate } from '../data/i18n';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile | null;
  onLogin: (user: UserProfile) => void;
  onLogout: () => void;
  language: LanguageCode;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  user,
  onLogin,
  onLogout,
  language,
}) => {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signup');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [oauthStep, setOauthStep] = useState<'idle' | 'popup' | 'success'>('idle');

  if (!isOpen) return null;

  const handleGoogleOAuth = () => {
    if (!firstName.trim() || !lastName.trim() || !email.trim()) {
      alert('Please enter your First Name, Last Name, and Email address below first to complete registration with Google.');
      return;
    }
    setIsAuthenticating(true);
    setOauthStep('popup');

    setTimeout(() => {
      const fn = firstName.trim();
      const ln = lastName.trim();
      const em = email.trim();
      const googleUser: UserProfile = {
        id: `usr_google_${Date.now()}`,
        firstName: fn,
        lastName: ln,
        name: `${fn} ${ln}`,
        email: em,
        avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(fn + ' ' + ln)}`,
        provider: 'google',
        preferredCurrency: 'USD',
        preferredLanguage: language,
        monthlyBudgetGoal: 4500,
        emailNotificationsEnabled: true,
      };
      setOauthStep('success');
      setTimeout(() => {
        setIsAuthenticating(false);
        setOauthStep('idle');
        onLogin(googleUser);
        onClose();
      }, 700);
    }, 1200);
  };

  const handleAppleOAuth = () => {
    if (!firstName.trim() || !lastName.trim() || !email.trim()) {
      alert('Please enter your First Name, Last Name, and Email address below first to complete registration with Apple.');
      return;
    }
    setIsAuthenticating(true);
    setOauthStep('popup');

    setTimeout(() => {
      const fn = firstName.trim();
      const ln = lastName.trim();
      const em = email.trim();
      const appleUser: UserProfile = {
        id: `usr_apple_${Date.now()}`,
        firstName: fn,
        lastName: ln,
        name: `${fn} ${ln}`,
        email: em,
        avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(fn + ' ' + ln)}`,
        provider: 'apple',
        preferredCurrency: 'EUR',
        preferredLanguage: language,
        monthlyBudgetGoal: 4000,
        emailNotificationsEnabled: true,
      };
      setOauthStep('success');
      setTimeout(() => {
        setIsAuthenticating(false);
        setOauthStep('idle');
        onLogin(appleUser);
        onClose();
      }, 700);
    }, 1200);
  };

  const handleEmailAuth = (e: React.FormEvent) => {
    e.preventDefault();
    const fn = firstName.trim();
    const ln = lastName.trim();
    const em = email.trim();

    if (authMode === 'signup' && (!fn || !ln || !em)) {
      alert('Please fill out First Name, Last Name, and Email address to register.');
      return;
    }

    if (!em) return;

    const userFirstName = fn || (em.split('@')[0] ? em.split('@')[0].charAt(0).toUpperCase() + em.split('@')[0].slice(1) : 'User');
    const userLastName = ln || '';

    setIsAuthenticating(true);
    setTimeout(() => {
      const emailUser: UserProfile = {
        id: `usr_mail_${Date.now()}`,
        firstName: userFirstName,
        lastName: userLastName,
        name: userLastName ? `${userFirstName} ${userLastName}` : userFirstName,
        email: em,
        avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(userFirstName + ' ' + userLastName)}`,
        provider: 'email',
        preferredCurrency: 'USD',
        preferredLanguage: language,
        monthlyBudgetGoal: 4000,
        emailNotificationsEnabled: true,
      };
      setIsAuthenticating(false);
      onLogin(emailUser);
      onClose();
    }, 800);
  };

  const handleDemoSignIn = () => {
    const demoUser: UserProfile = {
      id: 'usr_demo_101',
      firstName: 'Demo',
      lastName: 'User',
      name: 'Demo User',
      email: 'demo.user@example.com',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      provider: 'demo',
      preferredCurrency: 'USD',
      preferredLanguage: language,
      monthlyBudgetGoal: 4200,
      emailNotificationsEnabled: true,
    };
    onLogin(demoUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0C0C0E] border-t sm:border border-white/10 rounded-t-[36px] sm:rounded-[32px] shadow-2xl overflow-hidden p-6 sm:p-7 text-slate-100 max-h-[92vh] overflow-y-auto">
        {/* Mobile Bottom Sheet Pull Handle */}
        <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto mb-4 sm:hidden"></div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-2 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X size={18} />
        </button>

        {user ? (
          /* Logged In View */
          <div className="text-center py-2 space-y-5">
            <div className="relative inline-block">
              <img
                src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                alt={user.name}
                className="w-20 h-20 rounded-full object-cover mx-auto ring-4 ring-indigo-500/30"
              />
              <div className="absolute bottom-0 right-0 bg-indigo-500 text-white p-1 rounded-full border-2 border-[#0C0C0E]">
                <ShieldCheck size={14} />
              </div>
            </div>

            <div>
              <h3 className="text-xl font-bold text-white">{user.name}</h3>
              <p className="text-xs text-slate-400 mt-0.5">{user.email}</p>
              <div className="inline-flex items-center gap-1.5 mt-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[11px] text-indigo-400 font-semibold">
                <ShieldCheck size={12} />
                <span>
                  {user.provider === 'google' && 'Google OAuth Verified'}
                  {user.provider === 'apple' && 'Apple OAuth Verified'}
                  {user.provider === 'email' && 'Registered Email Account'}
                  {user.provider === 'demo' && 'Demo Session'}
                </span>
              </div>
            </div>

            <div className="bg-white/5 p-4 rounded-2xl border border-white/10 text-left space-y-2 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Account ID:</span>
                <span className="font-mono text-slate-200">{user.id}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Monthly Target:</span>
                <span className="font-bold text-emerald-400">${user.monthlyBudgetGoal.toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() => {
                onLogout();
                onClose();
              }}
              className="w-full flex items-center justify-center gap-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 font-bold py-3 rounded-full transition-all text-xs cursor-pointer"
            >
              <LogOut size={16} />
              <span>{translate('sign_out', language)}</span>
            </button>
          </div>
        ) : (
          /* Sign In / Sign Up Options */
          <div>
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl flex items-center justify-center mx-auto text-indigo-400 mb-3">
                <Sparkles size={24} />
              </div>
              <h2 className="text-2xl font-extrabold text-white tracking-tight">
                {authMode === 'signup' ? 'User Registration' : 'Welcome Back'}
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                {authMode === 'signup'
                  ? 'Register with your name and email to track budgets & expenses'
                  : 'Sign in to access your synced account'}
              </p>
            </div>

            {oauthStep === 'popup' ? (
              <div className="py-10 text-center space-y-4">
                <div className="w-12 h-12 border-4 border-indigo-500/30 border-t-indigo-400 rounded-full animate-spin mx-auto"></div>
                <p className="text-sm font-semibold text-slate-200">
                  Connecting to OAuth Provider...
                </p>
                <p className="text-xs text-slate-400">Exchanging secure credentials</p>
              </div>
            ) : oauthStep === 'success' ? (
              <div className="py-10 text-center space-y-3">
                <CheckCircle2 size={48} className="text-emerald-400 mx-auto animate-bounce" />
                <p className="text-sm font-bold text-emerald-300">Authentication Successful!</p>
                <p className="text-xs text-slate-400">Loading your profile data...</p>
              </div>
            ) : (
              <div className="space-y-3.5">
                {/* Google OAuth Button */}
                <button
                  onClick={handleGoogleOAuth}
                  disabled={isAuthenticating}
                  className="w-full flex items-center justify-center gap-3 bg-white/5 hover:bg-white/10 text-white font-semibold py-3 px-4 rounded-full border border-white/10 transition-all text-xs active:scale-[0.99] cursor-pointer"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>{translate('google_sign_in', language)}</span>
                </button>

                {/* Apple OAuth Button */}
                <button
                  onClick={handleAppleOAuth}
                  disabled={isAuthenticating}
                  className="w-full flex items-center justify-center gap-3 bg-white hover:bg-slate-100 text-black font-semibold py-3 px-4 rounded-full transition-all text-xs active:scale-[0.99] cursor-pointer"
                >
                  <svg className="w-4 h-4 fill-current" viewBox="0 0 170 170">
                    <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.34.13-9.13-1.9-14.37-6.08-3.32-2.65-7.25-7.28-11.78-13.88-6.17-8.99-11.02-18.9-14.54-29.73-3.53-10.83-5.29-21.2-5.29-31.1 0-14.28 3.73-26.04 11.19-35.28 7.46-9.24 16.82-13.97 28.09-14.19 4.34 0 9.28 1.15 14.82 3.45 5.54 2.3 9.4 3.45 11.58 3.45 1.98 0 5.96-1.22 11.95-3.66 5.98-2.43 10.81-3.56 14.48-3.38 10.23.63 18.66 4.34 25.29 11.13-9.19 5.56-13.68 13.39-13.48 23.49.23 7.82 3.25 14.55 9.06 20.19 5.81 5.64 12.87 8.94 21.18 9.9-.97 3.33-2.19 6.84-3.66 10.53zm-31.25-103.5c0 6.64-2.4 12.92-7.2 17.84-4.8 4.93-10.74 7.81-17.82 8.64-.17-.98-.25-1.89-.25-2.73 0-6.49 2.42-12.79 7.26-17.7 4.84-4.91 10.9-7.79 18.18-8.64.12.88.18 1.74.18 2.59z" />
                  </svg>
                  <span>{translate('apple_sign_in', language)}</span>
                </button>

                <div className="relative my-3">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-white/10"></div>
                  </div>
                  <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-widest">
                    <span className="bg-[#0C0C0E] px-2 text-slate-500">
                      {authMode === 'signup' ? 'Or register with email' : 'Or email login'}
                    </span>
                  </div>
                </div>

                {/* Registration / Email Form */}
                <form onSubmit={handleEmailAuth} className="space-y-3">
                  {authMode === 'signup' && (
                    <div className="grid grid-cols-2 gap-2">
                      <div className="relative">
                        <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          placeholder="First Name"
                          value={firstName}
                          onChange={(e) => setFirstName(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-full pl-9 pr-3 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-medium"
                          required
                        />
                      </div>
                      <div className="relative">
                        <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          placeholder="Last Name"
                          value={lastName}
                          onChange={(e) => setLastName(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-full pl-9 pr-3 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-medium"
                          required
                        />
                      </div>
                    </div>
                  )}

                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      placeholder="Email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-full pl-9 pr-4 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-medium"
                      required
                    />
                  </div>

                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="password"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full bg-white/5 border border-white/10 rounded-full pl-9 pr-4 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-medium"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isAuthenticating}
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-full transition-all text-xs shadow-lg shadow-indigo-600/30 cursor-pointer"
                  >
                    {authMode === 'signup' ? 'Complete Registration' : translate('sign_in', language)}
                  </button>
                </form>

                <div className="flex items-center justify-between text-[11px] pt-1">
                  <button
                    type="button"
                    onClick={() => setAuthMode(authMode === 'signin' ? 'signup' : 'signin')}
                    className="text-slate-400 hover:text-indigo-400 underline cursor-pointer"
                  >
                    {authMode === 'signup' ? 'Already have an account? Sign In' : "Need an account? Register"}
                  </button>

                  <button
                    type="button"
                    onClick={handleDemoSignIn}
                    className="text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
                  >
                    {translate('demo_mode', language)}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
