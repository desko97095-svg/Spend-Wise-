import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import {
  Search,
  Filter,
  PlusCircle,
  Receipt,
  Download,
  Trash2,
  Edit2,
  Calendar,
  CreditCard,
  Tag,
  ArrowUpDown,
  CheckCircle2,
} from 'lucide-react';
import { Transaction, CategoryId, CurrencyCode, LanguageCode } from '../types';
import { CATEGORIES } from '../data/defaultData';
import { formatCurrency } from '../data/currencies';
import { translate } from '../data/i18n';
import { CategoryIcon } from './CategoryIcon';

interface TransactionListProps {
  transactions: Transaction[];
  currency: CurrencyCode;
  language: LanguageCode;
  onOpenAddModal: (type?: 'expense' | 'income') => void;
  onEditTransaction: (tx: Transaction) => void;
  onDeleteTransaction: (id: string) => void;
}

export const TransactionList: React.FC<TransactionListProps> = ({
  transactions,
  currency,
  language,
  onOpenAddModal,
  onEditTransaction,
  onDeleteTransaction,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<'all' | 'expense' | 'income'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'amount_desc' | 'amount_asc'>('date_desc');

  const filteredTransactions = useMemo(() => {
    return transactions
      .filter((tx) => {
        // Search filter
        const matchSearch =
          tx.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          (tx.notes && tx.notes.toLowerCase().includes(searchTerm.toLowerCase())) ||
          (tx.tags && tx.tags.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase())));

        // Type filter
        const matchType = selectedType === 'all' || tx.type === selectedType;

        // Category filter
        const matchCategory = selectedCategory === 'all' || tx.category === selectedCategory;

        return matchSearch && matchType && matchCategory;
      })
      .sort((a, b) => {
        if (sortBy === 'date_desc') return new Date(b.date).getTime() - new Date(a.date).getTime();
        if (sortBy === 'date_asc') return new Date(a.date).getTime() - new Date(b.date).getTime();
        if (sortBy === 'amount_desc') return b.amount - a.amount;
        if (sortBy === 'amount_asc') return a.amount - b.amount;
        return 0;
      });
  }, [transactions, searchTerm, selectedType, selectedCategory, sortBy]);

  const handleExportCSV = () => {
    const headers = ['ID', 'Title', 'Type', 'Category', 'Amount (USD)', 'Date', 'Payment Method', 'Notes', 'Tags'];
    const rows = filteredTransactions.map((tx) => [
      tx.id,
      `"${tx.title.replace(/"/g, '""')}"`,
      tx.type,
      tx.category,
      tx.amount,
      tx.date,
      tx.paymentMethod,
      `"${(tx.notes || '').replace(/"/g, '""')}"`,
      `"${(tx.tags || []).join(', ')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SpendWise_Transactions_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Header & Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Receipt className="text-indigo-400" />
            <span>{translate('transactions', language)}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            View, filter, edit, and export your complete transaction history.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10 px-4 py-2 rounded-full text-xs font-bold transition-all cursor-pointer"
          >
            <Download size={15} className="text-indigo-400" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => onOpenAddModal()}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2 rounded-full font-bold text-xs shadow-lg shadow-indigo-500/25 transition-all cursor-pointer"
          >
            <PlusCircle size={16} />
            <span>{translate('add_expense', language)}</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Control Bar */}
      <div className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-5 rounded-3xl shadow-xl space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={translate('search_placeholder', language)}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-full pl-9 pr-4 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition-colors font-medium"
            />
          </div>

          {/* Type Selector */}
          <div className="relative">
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value as any)}
              className="w-full appearance-none bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer font-medium"
            >
              <option value="all" className="bg-[#0C0C0E]">{translate('filter_by_type', language)}</option>
              <option value="expense" className="bg-[#0C0C0E]">Expenses Only</option>
              <option value="income" className="bg-[#0C0C0E]">Income Only</option>
            </select>
          </div>

          {/* Category Selector */}
          <div className="relative">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full appearance-none bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer font-medium"
            >
              <option value="all" className="bg-[#0C0C0E]">{translate('filter_by_category', language)}</option>
              {CATEGORIES.map((cat) => (
                <option key={cat.id} value={cat.id} className="bg-[#0C0C0E]">
                  {translate(cat.nameKey, language)}
                </option>
              ))}
            </select>
          </div>

          {/* Sort Selector */}
          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full appearance-none bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 cursor-pointer font-medium"
            >
              <option value="date_desc" className="bg-[#0C0C0E]">Newest Date First</option>
              <option value="date_asc" className="bg-[#0C0C0E]">Oldest Date First</option>
              <option value="amount_desc" className="bg-[#0C0C0E]">Highest Amount First</option>
              <option value="amount_asc" className="bg-[#0C0C0E]">Lowest Amount First</option>
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-white/5">
          <span>
            Showing <strong className="text-white">{filteredTransactions.length}</strong> of{' '}
            <strong className="text-white">{transactions.length}</strong> transactions
          </span>

          {(searchTerm || selectedType !== 'all' || selectedCategory !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setSelectedType('all');
                setSelectedCategory('all');
              }}
              className="text-indigo-400 hover:text-indigo-300 font-semibold cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Transaction Feed Cards */}
      {filteredTransactions.length === 0 ? (
        <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-12 text-center text-slate-400 space-y-3">
          <Receipt size={40} className="mx-auto text-slate-600" />
          <p className="text-sm font-semibold text-slate-300">
            {translate('no_transactions', language)}
          </p>
          <button
            onClick={() => onOpenAddModal()}
            className="text-xs font-bold text-indigo-400 hover:text-indigo-300 underline"
          >
            Create a transaction now
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTransactions.map((tx) => {
            const catDef = CATEGORIES.find((c) => c.id === tx.category) || CATEGORIES[12];
            const isIncome = tx.type === 'income';

            return (
              <motion.div
                key={tx.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 hover:border-white/20 p-4 sm:p-5 rounded-2xl shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
              >
                <div className="flex items-start gap-3 sm:gap-4 min-w-0 flex-1">
                  <div className="shrink-0 mt-0.5">
                    <CategoryIcon iconName={catDef.iconName} color={catDef.color} size={20} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors truncate min-w-0">
                        {tx.title}
                      </h3>
                      {tx.isRecurring && (
                        <span className="px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[9px] font-bold uppercase tracking-widest whitespace-nowrap shrink-0">
                          Monthly
                        </span>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-400 mt-1">
                      <span className="flex items-center gap-1 whitespace-nowrap">
                        <Calendar size={12} className="shrink-0" />
                        <span className="whitespace-nowrap">{tx.date}</span>
                      </span>
                      <span>•</span>
                      <span className="capitalize whitespace-nowrap">{tx.paymentMethod.replace('_', ' ')}</span>
                      {tx.notes && (
                        <>
                          <span>•</span>
                          <span className="truncate max-w-[180px] italic text-slate-500">{tx.notes}</span>
                        </>
                      )}
                    </div>

                    {tx.tags && tx.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {tx.tags.map((tag) => (
                          <span
                            key={tag}
                            className="px-2.5 py-0.5 rounded-full bg-white/5 text-slate-400 border border-white/10 text-[10px] font-medium whitespace-nowrap"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3 sm:gap-4 border-t sm:border-t-0 border-white/5 pt-2 sm:pt-0 shrink-0">
                  <div className="text-right whitespace-nowrap shrink-0">
                    <div className={`text-base font-black font-mono whitespace-nowrap ${isIncome ? 'text-emerald-400' : 'text-slate-100'}`}>
                      <span className="inline-block whitespace-nowrap">{isIncome ? '+' : '-'}{formatCurrency(tx.amount, currency)}</span>
                    </div>
                    <span className="text-[10px] text-slate-400 uppercase tracking-widest font-bold whitespace-nowrap block">
                      {translate(catDef.nameKey, language)}
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => onEditTransaction(tx)}
                      className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
                      title="Edit Transaction"
                    >
                      <Edit2 size={15} />
                    </button>
                    <button
                      onClick={() => onDeleteTransaction(tx.id)}
                      className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-full transition-colors cursor-pointer"
                      title="Delete Transaction"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};
