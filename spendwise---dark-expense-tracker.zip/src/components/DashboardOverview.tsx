import React from 'react';
import { motion } from 'motion/react';
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  Sparkles,
  PieChart,
  ArrowUpRight,
  PlusCircle,
  Receipt,
  Calendar,
  CreditCard,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { Transaction, CategoryId, CurrencyCode, LanguageCode, UserProfile } from '../types';
import { CATEGORIES } from '../data/defaultData';
import { formatCurrency } from '../data/currencies';
import { translate } from '../data/i18n';
import { CategoryIcon } from './CategoryIcon';

interface DashboardOverviewProps {
  transactions: Transaction[];
  categoryBudgets: Record<CategoryId, number>;
  currency: CurrencyCode;
  language: LanguageCode;
  user: UserProfile | null;
  onNavigateToTab: (tab: 'transactions' | 'budgets' | 'ai_reports') => void;
  onOpenAddModal: (type?: 'expense' | 'income') => void;
  onOpenReportModal: () => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  transactions,
  categoryBudgets,
  currency,
  language,
  user,
  onNavigateToTab,
  onOpenAddModal,
  onOpenReportModal,
}) => {
  // Calculate Totals
  const totalIncome = transactions
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenses = transactions
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const netSavings = totalIncome - totalExpenses;
  const totalMonthlyBudget = (Object.values(categoryBudgets) as number[]).reduce((a, b) => a + b, 0);
  const budgetUsagePercent = totalMonthlyBudget > 0 ? Math.min(100, Math.round((totalExpenses / totalMonthlyBudget) * 100)) : 0;

  // Category spending calculation
  const categorySpentMap: Record<string, number> = {};
  transactions
    .filter((t) => t.type === 'expense')
    .forEach((t) => {
      categorySpentMap[t.category] = (categorySpentMap[t.category] || 0) + t.amount;
    });

  // Top 4 spending categories
  const sortedCategories = CATEGORIES.filter((c) => c.type === 'expense')
    .map((cat) => {
      const spent = categorySpentMap[cat.id] || 0;
      const budget = categoryBudgets[cat.id] || 1;
      const percent = Math.round((spent / budget) * 100);
      return { cat, spent, budget, percent };
    })
    .sort((a, b) => b.spent - a.spent)
    .slice(0, 4);

  // Recent 5 transactions
  const recentTransactions = [...transactions]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-4 pb-6">
      {/* Welcome & AI Banner */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden bg-gradient-to-br from-[#12141C] via-[#0E1017] to-[#0A0C12] p-5 sm:p-6 rounded-3xl border border-white/10 shadow-xl"
      >
        <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-indigo-600/10 rounded-full blur-[100px] pointer-events-none"></div>

        <div className="flex flex-col gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded-full border border-indigo-500/20">
                {new Date().toLocaleDateString(language, { month: 'short', year: 'numeric' })}
              </span>
              {budgetUsagePercent > 90 && (
                <span className="text-[10px] font-bold uppercase tracking-widest text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full border border-rose-500/20 flex items-center gap-1">
                  <AlertCircle size={10} /> {budgetUsagePercent}% Spent
                </span>
              )}
            </div>
            <h1 className="text-2xl font-extrabold text-white tracking-tight">
              Hello, <span className="text-indigo-400">{user?.firstName || (user?.name ? user.name.split(' ')[0] : 'Guest')}</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed font-normal">
              Track cash flow & AI insights on mobile
            </p>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={onOpenReportModal}
              className="flex-1 flex items-center justify-center gap-1.5 bg-gradient-to-r from-indigo-600 to-indigo-500 text-white px-3.5 py-2.5 rounded-full font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-200 animate-spin" style={{ animationDuration: '4s' }} />
              <span>AI Insights</span>
            </button>

            <button
              onClick={() => onOpenAddModal('expense')}
              className="flex-1 flex items-center justify-center gap-1.5 bg-white/10 hover:bg-white/15 text-white border border-white/15 px-3.5 py-2.5 rounded-full font-bold text-xs shadow-md transition-all active:scale-95 cursor-pointer"
            >
              <PlusCircle className="w-3.5 h-3.5 text-indigo-400" />
              <span>{translate('add_expense', language)}</span>
            </button>
          </div>
        </div>
      </motion.div>

      {/* Top 4 Key Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Net Savings / Total Balance */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-3xl shadow-xl hover:border-indigo-500/30 transition-all group"
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-slate-400 uppercase tracking-widest font-semibold">{translate('total_balance', language)}</span>
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Wallet size={18} />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white tracking-tight">
            {formatCurrency(netSavings, currency)}
          </div>
          <div className="flex items-center gap-1.5 text-xs text-emerald-400 mt-2.5 font-semibold">
            <TrendingUp size={14} />
            <span>Net cash surplus after expenses</span>
          </div>
        </motion.div>

        {/* Total Income */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-3xl shadow-xl hover:border-emerald-500/30 transition-all group"
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-slate-400 uppercase tracking-widest font-semibold">{translate('total_income', language)}</span>
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <TrendingUp size={18} />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white tracking-tight">
            {formatCurrency(totalIncome, currency)}
          </div>
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-2.5 font-medium">
            <span>Inflow across all accounts</span>
          </div>
        </motion.div>

        {/* Total Expenses */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-3xl shadow-xl hover:border-rose-500/30 transition-all group"
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-slate-400 uppercase tracking-widest font-semibold">{translate('total_expenses', language)}</span>
            <div className="w-10 h-10 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400">
              <TrendingDown size={18} />
            </div>
          </div>
          <div className="text-3xl font-extrabold text-white tracking-tight">
            {formatCurrency(totalExpenses, currency)}
          </div>
          <div className="flex items-center gap-1.5 text-xs text-rose-400 mt-2.5 font-semibold">
            <span>Outflow this period</span>
          </div>
        </motion.div>

        {/* Monthly Budget Consumption */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-3xl shadow-xl hover:border-indigo-500/30 transition-all group"
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-slate-400 uppercase tracking-widest font-semibold">{translate('monthly_budget', language)}</span>
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <PieChart size={18} />
            </div>
          </div>
          <div className="flex items-baseline justify-between">
            <div className="text-3xl font-extrabold text-white tracking-tight">
              {budgetUsagePercent}%
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {formatCurrency(totalExpenses, currency)} / {formatCurrency(totalMonthlyBudget, currency)}
            </span>
          </div>
          {/* Progress Bar */}
          <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden mt-3 border border-white/5">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                budgetUsagePercent > 100
                  ? 'bg-rose-500'
                  : budgetUsagePercent > 80
                  ? 'bg-amber-500'
                  : 'bg-indigo-500'
              }`}
              style={{ width: `${Math.min(100, budgetUsagePercent)}%` }}
            ></div>
          </div>
        </motion.div>
      </div>

      {/* Middle Section: Top Spending Categories + AI Automated Report Teaser */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Budget Progress Highlights */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="lg:col-span-2 bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 rounded-[32px] p-7 shadow-xl"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <PieChart className="w-5 h-5 text-indigo-400" />
                <span>{translate('category_budgets', language)}</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Top category allocations & budget utilization status
              </p>
            </div>
            <button
              onClick={() => onNavigateToTab('budgets')}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 px-4 py-2 rounded-full border border-indigo-500/20 transition-all cursor-pointer"
            >
              <span>{translate('view_all', language)}</span>
              <ArrowUpRight size={14} />
            </button>
          </div>

          <div className="space-y-4">
            {sortedCategories.map(({ cat, spent, budget, percent }) => (
              <div key={cat.id} className="p-4 bg-white/[0.02] rounded-2xl border border-white/5 hover:border-white/10 transition-colors">
                <div className="flex items-center justify-between mb-2.5">
                  <div className="flex items-center gap-3">
                    <CategoryIcon iconName={cat.iconName} color={cat.color} size={20} />
                    <div>
                      <div className="text-sm font-bold text-slate-100">
                        {translate(cat.nameKey, language)}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {formatCurrency(spent, currency)} spent of {formatCurrency(budget, currency)} limit
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-xs font-bold px-3 py-1 rounded-full border ${
                        percent >= 100
                          ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                          : percent >= 80
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                          : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20'
                      }`}
                    >
                      {percent}% Used
                    </span>
                  </div>
                </div>

                <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden border border-white/5">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      percent >= 100 ? 'bg-rose-500' : percent >= 80 ? 'bg-amber-500' : 'bg-indigo-500'
                    }`}
                    style={{ width: `${Math.min(100, percent)}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* AI Report Card Teaser */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-gradient-to-br from-indigo-950/40 via-[#12141C] to-[#0A0C12] border border-indigo-500/30 rounded-[32px] p-7 shadow-2xl flex flex-col justify-between relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-40 h-40 bg-indigo-600/15 rounded-full blur-[80px] pointer-events-none"></div>

          <div>
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-300 mb-5 shadow-lg shadow-indigo-500/10">
              <Sparkles size={24} />
            </div>

            <h3 className="text-xl font-extrabold text-white mb-2 tracking-tight">
              Automated AI Budgeting Reports
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed mb-5">
              Get an instant comprehensive monthly financial analysis powered by Gemini AI. Uncover hidden spending trends, detect budget anomalies, and receive tailored savings strategies.
            </p>

            <div className="space-y-2.5 text-xs text-slate-300 mb-6">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 size={15} className="text-indigo-400 shrink-0" />
                <span>Financial health score calculation</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 size={15} className="text-indigo-400 shrink-0" />
                <span>Category variance & wastage detection</span>
              </div>
              <div className="flex items-center gap-2.5">
                <CheckCircle2 size={15} className="text-indigo-400 shrink-0" />
                <span>Next month forecast & recommended budget targets</span>
              </div>
            </div>
          </div>

          <button
            onClick={onOpenReportModal}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3.5 px-5 rounded-full text-xs transition-all flex items-center justify-center gap-2 shadow-xl shadow-indigo-600/30 active:scale-95 cursor-pointer"
          >
            <Sparkles size={16} />
            <span>Generate Monthly Report Now</span>
          </button>
        </motion.div>
      </div>

      {/* Recent Transactions List */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35 }}
        className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 rounded-[32px] p-7 shadow-xl"
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Receipt className="w-5 h-5 text-indigo-400" />
              <span>{translate('recent_transactions', language)}</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Latest income and expense entries
            </p>
          </div>

          <button
            onClick={() => onNavigateToTab('transactions')}
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 px-4 py-2 rounded-full border border-indigo-500/20 transition-all cursor-pointer"
          >
            <span>{translate('view_all', language)}</span>
            <ArrowUpRight size={14} />
          </button>
        </div>

        <div className="space-y-3">
          {recentTransactions.length === 0 ? (
            <div className="p-8 text-center bg-white/[0.02] border border-white/5 rounded-2xl text-slate-400 space-y-2.5">
              <Receipt className="w-8 h-8 mx-auto text-slate-600" />
              <p className="text-xs font-semibold text-slate-300">No transactions added yet</p>
              <button
                onClick={() => onOpenAddModal('expense')}
                className="text-xs font-bold text-indigo-400 hover:text-indigo-300 underline cursor-pointer"
              >
                + Add your first transaction
              </button>
            </div>
          ) : (
            recentTransactions.map((tx) => {
              const catDef = CATEGORIES.find((c) => c.id === tx.category) || CATEGORIES[12];
              const isIncome = tx.type === 'income';

              return (
                <div
                  key={tx.id}
                  className="flex items-center justify-between p-4 bg-white/[0.02] rounded-2xl border border-white/5 hover:border-white/10 transition-all hover:bg-white/[0.04] group cursor-pointer gap-3"
                >
                  <div className="flex items-center gap-3.5 min-w-0 flex-1">
                    <div className="shrink-0">
                      <CategoryIcon iconName={catDef.iconName} color={catDef.color} size={20} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors truncate">
                        {tx.title}
                      </div>
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-slate-400 mt-0.5">
                        <span className="flex items-center gap-1 whitespace-nowrap">
                          <Calendar size={11} className="shrink-0" />
                          <span className="whitespace-nowrap">{tx.date}</span>
                        </span>
                        <span>•</span>
                        <span className="capitalize whitespace-nowrap">{tx.paymentMethod.replace('_', ' ')}</span>
                        {tx.isRecurring && (
                          <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-400 rounded-full text-[9px] border border-indigo-500/20 font-semibold uppercase tracking-wider whitespace-nowrap shrink-0">
                            Recurring
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0 whitespace-nowrap">
                    <div className={`text-sm font-black font-mono whitespace-nowrap ${isIncome ? 'text-emerald-400' : 'text-slate-100'}`}>
                      <span className="inline-block whitespace-nowrap">{isIncome ? '+' : '-'}{formatCurrency(tx.amount, currency)}</span>
                    </div>
                    <div className="text-[10px] text-slate-500 capitalize font-medium whitespace-nowrap">{translate(catDef.nameKey, language)}</div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </motion.div>
    </div>
  );
};
