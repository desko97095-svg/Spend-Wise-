import React from 'react';
import { X, Settings, Globe, Coins, ShieldCheck, RefreshCw, Bell, Sparkles } from 'lucide-react';
import { CurrencyCode, LanguageCode, UserProfile } from '../types';
import { CURRENCIES } from '../data/currencies';
import { LANGUAGES, translate } from '../data/i18n';

interface UserSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: CurrencyCode;
  setCurrency: (currency: CurrencyCode) => void;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  user: UserProfile | null;
  onResetData: () => void;
}

export const UserSettingsModal: React.FC<UserSettingsModalProps> = ({
  isOpen,
  onClose,
  currency,
  setCurrency,
  language,
  setLanguage,
  user,
  onResetData,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0C0C0E] border-t sm:border border-white/10 rounded-t-[36px] sm:rounded-[32px] shadow-2xl overflow-hidden p-6 sm:p-7 text-slate-100 max-h-[92vh] overflow-y-auto">
        {/* Mobile Bottom Sheet Pull Handle */}
        <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto mb-4 sm:hidden"></div>

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <h2 className="text-xl font-extrabold text-white flex items-center gap-2">
            <Settings className="text-indigo-400" />
            <span>App Preferences & Settings</span>
          </h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <div className="space-y-5 pt-4">
          {/* Active User Account */}
          <div className="p-4 bg-white/5 rounded-2xl border border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src={user?.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'}
                alt={user?.name || 'User'}
                className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/30"
              />
              <div>
                <div className="text-sm font-bold text-white">{user?.name || 'Guest Explorer'}</div>
                <div className="text-xs text-slate-400">{user?.email || 'Guest Mode'}</div>
              </div>
            </div>
            <div className="px-3 py-1 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[10px] font-bold rounded-full flex items-center gap-1">
              <ShieldCheck size={12} /> OAuth Active
            </div>
          </div>

          {/* Currency Preference */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-2">
              <Coins size={14} className="text-amber-400" />
              <span>Preferred Base Currency</span>
            </label>
            <select
              value={currency}
              onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
              className="w-full bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 font-medium cursor-pointer"
            >
              {Object.values(CURRENCIES).map((c) => (
                <option key={c.code} value={c.code} className="bg-[#0C0C0E]">
                  {c.flag} {c.name} ({c.code} - {c.symbol})
                </option>
              ))}
            </select>
          </div>

          {/* Language Preference */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-2">
              <Globe size={14} className="text-indigo-400" />
              <span>UI Language Localization</span>
            </label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as LanguageCode)}
              className="w-full bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 font-medium cursor-pointer"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code} className="bg-[#0C0C0E]">
                  {l.flag} {l.name} ({l.nativeName})
                </option>
              ))}
            </select>
          </div>

          {/* Clear All Data Option */}
          <div className="pt-3 border-t border-white/10">
            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to clear all transactions and reset category budgets to empty?')) {
                  onResetData();
                  onClose();
                }
              }}
              className="w-full flex items-center justify-center gap-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 py-3 rounded-full text-xs font-bold transition-all cursor-pointer"
            >
              <RefreshCw size={14} />
              <span>Clear All Data & Reset</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
