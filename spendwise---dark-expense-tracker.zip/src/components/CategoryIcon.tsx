import React from 'react';
import {
  Home,
  Utensils,
  Car,
  Laptop,
  Tv,
  ShoppingBag,
  Zap,
  HeartPulse,
  Plane,
  TrendingUp,
  Briefcase,
  Code,
  MoreHorizontal,
  LucideIcon,
} from 'lucide-react';
import { CategoryId } from '../types';

const ICON_MAP: Record<string, LucideIcon> = {
  Home,
  Utensils,
  Car,
  Laptop,
  Tv,
  ShoppingBag,
  Zap,
  HeartPulse,
  Plane,
  TrendingUp,
  Briefcase,
  Code,
  MoreHorizontal,
};

const COLOR_MAP: Record<string, { bg: string; text: string; border: string }> = {
  emerald: { bg: 'bg-emerald-500/10', text: 'text-emerald-400', border: 'border-emerald-500/20' },
  amber: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/20' },
  blue: { bg: 'bg-blue-500/10', text: 'text-blue-400', border: 'border-blue-500/20' },
  cyan: { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'border-cyan-500/20' },
  purple: { bg: 'bg-purple-500/10', text: 'text-purple-400', border: 'border-purple-500/20' },
  pink: { bg: 'bg-pink-500/10', text: 'text-pink-400', border: 'border-pink-500/20' },
  orange: { bg: 'bg-orange-500/10', text: 'text-orange-400', border: 'border-orange-500/20' },
  rose: { bg: 'bg-rose-500/10', text: 'text-rose-400', border: 'border-rose-500/20' },
  indigo: { bg: 'bg-indigo-500/10', text: 'text-indigo-400', border: 'border-indigo-500/20' },
  teal: { bg: 'bg-teal-500/10', text: 'text-teal-400', border: 'border-teal-500/20' },
  gray: { bg: 'bg-slate-500/10', text: 'text-slate-400', border: 'border-slate-500/20' },
};

interface CategoryIconProps {
  iconName: string;
  color?: string;
  className?: string;
  size?: number;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({
  iconName,
  color = 'blue',
  className = '',
  size = 18,
}) => {
  const IconComponent = ICON_MAP[iconName] || MoreHorizontal;
  const colorStyle = COLOR_MAP[color] || COLOR_MAP.gray;

  return (
    <div
      className={`inline-flex items-center justify-center p-2 rounded-xl border ${colorStyle.bg} ${colorStyle.text} ${colorStyle.border} ${className}`}
    >
      <IconComponent size={size} />
    </div>
  );
};
