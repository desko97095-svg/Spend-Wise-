import React from 'react';
import {
  LayoutDashboard,
  Receipt,
  PieChart,
  Sparkles,
  Globe,
  Coins,
  Settings,
  Plus,
} from 'lucide-react';
import { CurrencyCode, LanguageCode, UserProfile } from '../types';
import { CURRENCIES } from '../data/currencies';
import { LANGUAGES, translate } from '../data/i18n';

interface NavbarProps {
  activeTab: 'dashboard' | 'transactions' | 'budgets' | 'analytics' | 'ai_reports';
  setActiveTab: (tab: 'dashboard' | 'transactions' | 'budgets' | 'analytics' | 'ai_reports') => void;
  currency: CurrencyCode;
  setCurrency: (currency: CurrencyCode) => void;
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  user: UserProfile | null;
  onOpenAuthModal: () => void;
  onOpenAddModal: () => void;
  onOpenSettings: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currency,
  setCurrency,
  language,
  setLanguage,
  user,
  onOpenAuthModal,
  onOpenAddModal,
  onOpenSettings,
}) => {
  return (
    <>
      {/* Mobile Top Header Bar */}
      <header className="sticky top-0 z-40 bg-[#0C0C0E]/95 backdrop-blur-2xl border-b border-white/10 px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          {/* Left: User Profile Avatar */}
          <button
            onClick={onOpenAuthModal}
            className="flex items-center gap-2 p-1 pr-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full transition-all group shrink-0"
            title="Profile & Account"
          >
            <div className="relative">
              <img
                src={user?.avatarUrl || 'https://api.dicebear.com/7.x/initials/svg?seed=Register'}
                alt={user?.name || 'User'}
                className="w-7 h-7 rounded-full object-cover ring-2 ring-indigo-500/40 bg-indigo-950"
              />
              <span className={`absolute bottom-0 right-0 w-2 h-2 rounded-full ring-2 ring-[#0C0C0E] ${user ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
            </div>
            <span className="text-xs font-bold text-slate-200 max-w-[80px] truncate">
              {user ? (user.firstName || user.name.split(' ')[0]) : 'Register'}
            </span>
          </button>

          {/* Center: App Brand */}
          <div className="flex items-center gap-1.5 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="w-7 h-7 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-black shadow-md shadow-indigo-500/30">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-black text-base tracking-tight text-white">
              Spend<span className="text-indigo-400">Wise</span>
            </span>
          </div>

          {/* Right: Controls (Currency, Language, Settings) */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Currency Selector */}
            <div className="relative">
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                className="appearance-none bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10 rounded-full text-[11px] font-bold pl-6 pr-3 py-1.5 cursor-pointer focus:outline-none transition-colors"
                title="Currency"
              >
                {Object.values(CURRENCIES).map((c) => (
                  <option key={c.code} value={c.code} className="bg-[#0C0C0E] text-white">
                    {c.flag} {c.code}
                  </option>
                ))}
              </select>
              <Coins className="w-3 h-3 text-amber-400 absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* Language Selector */}
            <div className="relative">
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as LanguageCode)}
                className="appearance-none bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded-full text-[11px] font-bold pl-6 pr-3 py-1.5 cursor-pointer focus:outline-none transition-colors"
                title="Language"
              >
                {LANGUAGES.map((l) => (
                  <option key={l.code} value={l.code} className="bg-[#0C0C0E] text-white">
                    {l.flag} {l.code.toUpperCase()}
                  </option>
                ))}
              </select>
              <Globe className="w-3 h-3 text-indigo-400 absolute left-2 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {/* Settings button */}
            <button
              onClick={onOpenSettings}
              className="p-1.5 text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-full transition-colors cursor-pointer"
              title="Settings"
            >
              <Settings size={15} />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Bottom Navigation Dock with Central FAB */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 bg-[#0C0C0E]/95 backdrop-blur-2xl border-t border-white/10 px-3 py-2">
        <div className="max-w-md mx-auto flex items-center justify-between relative">
          {/* Dashboard Tab */}
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'dashboard' ? 'text-indigo-400 font-bold scale-105' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <LayoutDashboard size={20} />
            <span className="text-[10px] tracking-tight">{translate('dashboard', language)}</span>
          </button>

          {/* Transactions Tab */}
          <button
            onClick={() => setActiveTab('transactions')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'transactions' ? 'text-indigo-400 font-bold scale-105' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Receipt size={20} />
            <span className="text-[10px] tracking-tight">{translate('transactions', language)}</span>
          </button>

          {/* Center Floating Action Button (FAB) */}
          <div className="relative -top-5 flex justify-center">
            <button
              onClick={onOpenAddModal}
              className="w-13 h-13 bg-gradient-to-tr from-indigo-600 via-indigo-500 to-purple-500 hover:from-indigo-500 hover:to-purple-400 text-white rounded-full shadow-lg shadow-indigo-500/40 border-4 border-[#09090B] flex items-center justify-center transition-all active:scale-90 cursor-pointer group"
              title="Add New Transaction"
            >
              <Plus size={26} className="group-hover:rotate-90 transition-transform duration-200" />
            </button>
          </div>

          {/* Budgets Tab */}
          <button
            onClick={() => setActiveTab('budgets')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'budgets' ? 'text-indigo-400 font-bold scale-105' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PieChart size={20} />
            <span className="text-[10px] tracking-tight">{translate('budgets', language)}</span>
          </button>

          {/* AI Reports Tab */}
          <button
            onClick={() => setActiveTab('ai_reports')}
            className={`flex flex-col items-center gap-1 py-1 px-3 rounded-2xl transition-all cursor-pointer ${
              activeTab === 'ai_reports' ? 'text-indigo-400 font-bold scale-105' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles size={20} className={activeTab === 'ai_reports' ? 'text-indigo-400 animate-pulse' : ''} />
            <span className="text-[10px] tracking-tight">{translate('ai_reports', language)}</span>
          </button>
        </div>
      </nav>
    </>
  );
};

