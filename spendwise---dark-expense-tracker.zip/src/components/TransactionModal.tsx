import React, { useState, useEffect } from 'react';
import { X, Sparkles, Plus, Check, DollarSign, Calendar, CreditCard, Tag, FileText } from 'lucide-react';
import { Transaction, TransactionType, CategoryId, PaymentMethod, LanguageCode } from '../types';
import { CATEGORIES } from '../data/defaultData';
import { translate } from '../data/i18n';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (tx: Omit<Transaction, 'id'>, editId?: string) => void;
  initialType?: TransactionType;
  editingTransaction?: Transaction | null;
  language: LanguageCode;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialType = 'expense',
  editingTransaction,
  language,
}) => {
  const [type, setType] = useState<TransactionType>(initialType);
  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<CategoryId>('food');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('credit_card');
  const [notes, setNotes] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [isRecurring, setIsRecurring] = useState(false);
  const [isAutoCategorizing, setIsAutoCategorizing] = useState(false);

  useEffect(() => {
    if (editingTransaction) {
      setType(editingTransaction.type);
      setTitle(editingTransaction.title);
      setAmount(editingTransaction.amount.toString());
      setCategory(editingTransaction.category);
      setDate(editingTransaction.date);
      setPaymentMethod(editingTransaction.paymentMethod);
      setNotes(editingTransaction.notes || '');
      setTags(editingTransaction.tags || []);
      setIsRecurring(editingTransaction.isRecurring || false);
    } else {
      setType(initialType);
      setTitle('');
      setAmount('');
      setCategory(initialType === 'income' ? 'salary' : 'food');
      setDate(new Date().toISOString().slice(0, 10));
      setPaymentMethod('credit_card');
      setNotes('');
      setTags([]);
      setIsRecurring(false);
    }
  }, [editingTransaction, initialType, isOpen]);

  if (!isOpen) return null;

  const handleAutoCategorize = async () => {
    if (!title) return;
    setIsAutoCategorizing(true);
    try {
      const res = await fetch('/api/ai/categorize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, amount: parseFloat(amount) || 0 }),
      });
      const data = await res.json();
      if (data.category && CATEGORIES.some((c) => c.id === data.category)) {
        setCategory(data.category as CategoryId);
      }
      if (data.suggestedTags && Array.isArray(data.suggestedTags)) {
        setTags(Array.from(new Set([...tags, ...data.suggestedTags])));
      }
    } catch (err) {
      console.error('Categorization error:', err);
    } finally {
      setIsAutoCategorizing(false);
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim().toLowerCase())) {
      setTags([...tags, tagInput.trim().toLowerCase()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter((t) => t !== tagToRemove));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!title || isNaN(numAmount) || numAmount <= 0) return;

    onSave(
      {
        title,
        amount: numAmount,
        type,
        category,
        date,
        paymentMethod,
        notes,
        tags,
        isRecurring,
      },
      editingTransaction?.id
    );
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0C0C0E] border-t sm:border border-white/10 rounded-t-[36px] sm:rounded-[32px] shadow-2xl overflow-hidden p-6 sm:p-7 text-slate-100 max-h-[92vh] overflow-y-auto">
        {/* Mobile Bottom Sheet Pull Handle */}
        <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto mb-4 sm:hidden"></div>

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <h2 className="text-xl font-extrabold text-white tracking-tight">
            {editingTransaction ? 'Edit Transaction' : 'New Transaction'}
          </h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          {/* Type Selector Tabs */}
          <div className="grid grid-cols-2 gap-2 p-1.5 bg-white/5 rounded-full border border-white/10">
            <button
              type="button"
              onClick={() => setType('expense')}
              className={`py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
                type === 'expense'
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/25'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Expense (-)
            </button>
            <button
              type="button"
              onClick={() => setType('income')}
              className={`py-2 rounded-full text-xs font-bold transition-all cursor-pointer ${
                type === 'income'
                  ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/25'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Income (+)
            </button>
          </div>

          {/* Title & AI Smart Categorize Button */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Transaction Title</label>
            <div className="relative flex items-center gap-2">
              <input
                type="text"
                placeholder="e.g., Whole Foods Market, Rent, Client Pay"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-medium"
                required
              />
              <button
                type="button"
                onClick={handleAutoCategorize}
                disabled={!title || isAutoCategorizing}
                className="shrink-0 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-4 py-2.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 disabled:opacity-40 cursor-pointer"
                title="AI Auto Categorize"
              >
                <Sparkles size={14} className={isAutoCategorizing ? 'animate-spin' : ''} />
                <span className="hidden sm:inline">AI Tag</span>
              </button>
            </div>
          </div>

          {/* Amount & Date Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Amount (USD Base)</label>
              <div className="relative">
                <DollarSign className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-full pl-9 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-mono font-bold"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Date</label>
              <div className="relative">
                <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-full pl-9 pr-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 font-medium"
                  required
                />
              </div>
            </div>
          </div>

          {/* Category & Payment Method Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as CategoryId)}
                className="w-full bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 font-medium capitalize cursor-pointer"
              >
                {CATEGORIES.filter((c) => c.type === type || type === 'expense').map((c) => (
                  <option key={c.id} value={c.id} className="bg-[#0C0C0E] text-white">
                    {translate(c.nameKey, language)}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Payment Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-indigo-500 font-medium cursor-pointer"
              >
                <option value="credit_card" className="bg-[#0C0C0E]">Credit Card</option>
                <option value="debit_card" className="bg-[#0C0C0E]">Debit Card</option>
                <option value="bank_transfer" className="bg-[#0C0C0E]">Bank Transfer</option>
                <option value="apple_pay" className="bg-[#0C0C0E]">Apple Pay</option>
                <option value="google_pay" className="bg-[#0C0C0E]">Google Pay</option>
                <option value="cash" className="bg-[#0C0C0E]">Cash</option>
              </select>
            </div>
          </div>

          {/* Notes & Tags */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Notes (Optional)</label>
            <input
              type="text"
              placeholder="e.g., Dinner with friends, monthly software renewal"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-medium"
            />
          </div>

          {/* Tags */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Tags</label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Add tag and press Enter"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
                className="w-full bg-white/5 border border-white/10 rounded-full px-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 font-medium"
              />
              <button
                type="button"
                onClick={handleAddTag}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 rounded-full text-xs font-bold cursor-pointer transition-all"
              >
                Add
              </button>
            </div>

            {tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {tags.map((t) => (
                  <span
                    key={t}
                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[11px] font-semibold"
                  >
                    #{t}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(t)}
                      className="hover:text-rose-400 cursor-pointer ml-0.5"
                    >
                      <X size={12} />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Recurring Toggle */}
          <div className="flex items-center gap-2.5 pt-1">
            <input
              type="checkbox"
              id="recurringToggle"
              checked={isRecurring}
              onChange={(e) => setIsRecurring(e.target.checked)}
              className="w-4 h-4 rounded border-white/10 bg-white/5 text-indigo-600 focus:ring-indigo-500/30 cursor-pointer"
            />
            <label htmlFor="recurringToggle" className="text-xs text-slate-300 font-medium cursor-pointer">
              Mark as recurring monthly transaction
            </label>
          </div>

          {/* Submit */}
          <div className="pt-3">
            <button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3.5 rounded-full transition-all text-xs shadow-xl shadow-indigo-600/30 active:scale-95 cursor-pointer"
            >
              {editingTransaction ? 'Save Changes' : 'Add Transaction'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
