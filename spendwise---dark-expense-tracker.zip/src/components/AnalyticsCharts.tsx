import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BarChart3, TrendingUp, DollarSign, Calendar, PieChart as PieIcon, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from 'recharts';
import { Transaction, CurrencyCode, LanguageCode } from '../types';
import { CATEGORIES } from '../data/defaultData';
import { formatCurrency } from '../data/currencies';
import { translate } from '../data/i18n';

interface AnalyticsChartsProps {
  transactions: Transaction[];
  currency: CurrencyCode;
  language: LanguageCode;
}

const COLORS = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ec4899', '#06b6d4', '#f43f5e', '#64748b'];

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({ transactions, currency, language }) => {
  const [timeframe, setTimeframe] = useState<'all' | 'month' | 'week'>('month');

  // Filter transactions by timeframe
  const filteredTx = transactions.filter((tx) => {
    if (timeframe === 'month') return tx.date.startsWith('2026-08');
    return true;
  });

  const totalIncome = filteredTx.filter((t) => t.type === 'income').reduce((s, t) => s + t.amount, 0);
  const totalExpense = filteredTx.filter((t) => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const savingsRate = totalIncome > 0 ? Math.round(((totalIncome - totalExpense) / totalIncome) * 100) : 0;

  // Category breakdown for Pie
  const categoryMap: Record<string, number> = {};
  filteredTx
    .filter((t) => t.type === 'expense')
    .forEach((t) => {
      categoryMap[t.category] = (categoryMap[t.category] || 0) + t.amount;
    });

  const pieData = Object.entries(categoryMap).map(([catId, amount]) => {
    const catDef = CATEGORIES.find((c) => c.id === catId) || CATEGORIES[12];
    return {
      name: translate(catDef.nameKey, language),
      value: amount,
    };
  });

  // Monthly comparison bar data
  const monthlyBarData = [
    { month: 'May 2026', Income: 5200, Expense: 3400 },
    { month: 'Jun 2026', Income: 5500, Expense: 3650 },
    { month: 'Jul 2026', Income: 6100, Expense: 3900 },
    { month: 'Aug 2026', Income: totalIncome, Expense: totalExpense },
  ];

  // Cashflow Area Data
  const areaData = Array.from({ length: 8 }, (_, i) => {
    const day = (i + 1) * 4;
    return {
      day: `Day ${day}`,
      CashBalance: 2000 + i * 350 - (i % 2 === 0 ? 150 : 50),
    };
  });

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <BarChart3 className="text-emerald-400" />
            <span>{translate('analytics', language)}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Visual income vs expenditure ratios, cash flow velocity, and category distribution.
          </p>
        </div>

        {/* Timeframe selector */}
        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setTimeframe('month')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              timeframe === 'month' ? 'bg-emerald-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            This Month
          </button>
          <button
            onClick={() => setTimeframe('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              timeframe === 'all' ? 'bg-emerald-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            All History
          </button>
        </div>
      </div>

      {/* Analytics Summary Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-3xl shadow-xl flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 uppercase tracking-widest font-semibold">Net Surplus</div>
            <div className="text-2xl font-extrabold text-white mt-1.5 font-mono">
              {formatCurrency(totalIncome - totalExpense, currency)}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/20">
            <ArrowUpRight size={22} />
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-3xl shadow-xl flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 uppercase tracking-widest font-semibold">Net Savings Rate</div>
            <div className="text-2xl font-extrabold text-emerald-400 mt-1.5 font-mono">{savingsRate}%</div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20">
            <TrendingUp size={22} />
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-3xl shadow-xl flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400 uppercase tracking-widest font-semibold">Top Expense Area</div>
            <div className="text-2xl font-extrabold text-white mt-1.5 capitalize">
              {pieData[0]?.name || 'Food'}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center border border-indigo-500/20">
            <PieIcon size={22} />
          </div>
        </div>
      </div>

      {/* Main Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Income vs Expense Bar Chart */}
        <div className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 rounded-[32px] p-6 shadow-xl">
          <h3 className="text-sm font-bold text-white mb-1 flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-indigo-400" />
            <span>Monthly Cash Flow Comparison</span>
          </h3>
          <p className="text-xs text-slate-400 mb-4">Income inflow vs expense outflow trajectory</p>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthlyBarData}>
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#09090B', borderColor: '#27272a', borderRadius: '16px', fontSize: '12px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="Income" fill="#6366f1" radius={[6, 6, 0, 0]} />
                <Bar dataKey="Expense" fill="#f43f5e" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Share Pie Chart */}
        <div className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 rounded-[32px] p-6 shadow-xl">
          <h3 className="text-sm font-bold text-white mb-1 flex items-center gap-2">
            <PieIcon className="w-4 h-4 text-indigo-400" />
            <span>Expenditure Share by Category</span>
          </h3>
          <p className="text-xs text-slate-400 mb-4">Visual breakdown of variable and fixed costs</p>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#09090B', borderColor: '#27272a', borderRadius: '16px', fontSize: '12px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Accumulation Area Chart */}
      <div className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 rounded-[32px] p-6 shadow-xl">
        <h3 className="text-sm font-bold text-white mb-1 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          <span>Cumulative Net Cash Reserves</span>
        </h3>
        <p className="text-xs text-slate-400 mb-4">Growth of liquidity balance throughout current period</p>

        <div className="h-56 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={areaData}>
              <XAxis dataKey="day" stroke="#64748b" fontSize={11} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#09090B', borderColor: '#27272a', borderRadius: '16px', fontSize: '12px' }}
              />
              <Area type="monotone" dataKey="CashBalance" stroke="#6366f1" fill="#6366f120" strokeWidth={3} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
