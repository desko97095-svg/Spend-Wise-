import React, { useState } from 'react';
import { motion } from 'motion/react';
import { PieChart, Save, AlertTriangle, CheckCircle2, TrendingUp, Sliders } from 'lucide-react';
import { CategoryId, CurrencyCode, LanguageCode, Transaction } from '../types';
import { CATEGORIES } from '../data/defaultData';
import { formatCurrency } from '../data/currencies';
import { translate } from '../data/i18n';
import { CategoryIcon } from './CategoryIcon';

interface BudgetManagerProps {
  categoryBudgets: Record<CategoryId, number>;
  onUpdateBudgets: (newBudgets: Record<CategoryId, number>) => void;
  transactions: Transaction[];
  currency: CurrencyCode;
  language: LanguageCode;
}

export const BudgetManager: React.FC<BudgetManagerProps> = ({
  categoryBudgets,
  onUpdateBudgets,
  transactions,
  currency,
  language,
}) => {
  const [editingBudgets, setEditingBudgets] = useState<Record<CategoryId, number>>({ ...categoryBudgets });
  const [isSavedAlert, setIsSavedAlert] = useState(false);

  // Compute category spent
  const categorySpentMap: Record<string, number> = {};
  transactions
    .filter((t) => t.type === 'expense')
    .forEach((t) => {
      categorySpentMap[t.category] = (categorySpentMap[t.category] || 0) + t.amount;
    });

  const expenseCategories = CATEGORIES.filter((c) => c.type === 'expense');

  const totalBudgeted = (Object.values(editingBudgets) as number[]).reduce((a, b) => a + b, 0);
  const totalSpent = (Object.values(categorySpentMap) as number[]).reduce((a, b) => a + b, 0);

  const handleBudgetChange = (catId: CategoryId, val: number) => {
    setEditingBudgets((prev) => ({
      ...prev,
      [catId]: Math.max(0, val),
    }));
  };

  const handleSaveAll = () => {
    onUpdateBudgets(editingBudgets);
    setIsSavedAlert(true);
    setTimeout(() => setIsSavedAlert(false), 2500);
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <PieChart className="text-indigo-400" />
            <span>{translate('budgets', language)}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Configure target category spending caps, monitor threshold alerts, and optimize monthly targets.
          </p>
        </div>

        <button
          onClick={handleSaveAll}
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-5 py-3 rounded-full shadow-lg shadow-indigo-500/25 transition-all active:scale-95 cursor-pointer text-xs self-start md:self-auto"
        >
          <Save size={16} />
          <span>{translate('save', language)} Budget Limits</span>
        </button>
      </div>

      {isSavedAlert && (
        <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-2xl text-xs font-semibold flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle2 size={16} />
          <span>Monthly Category Budget limits successfully updated and persisted!</span>
        </div>
      )}

      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-3xl shadow-xl">
          <div className="text-xs text-slate-400 uppercase tracking-widest font-semibold">Total Monthly Target</div>
          <div className="text-3xl font-extrabold text-white mt-1.5">
            {formatCurrency(totalBudgeted, currency)}
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-3xl shadow-xl">
          <div className="text-xs text-slate-400 uppercase tracking-widest font-semibold">Actual Spent This Month</div>
          <div className="text-3xl font-extrabold text-rose-400 mt-1.5">
            {formatCurrency(totalSpent, currency)}
          </div>
        </div>

        <div className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-3xl shadow-xl">
          <div className="text-xs text-slate-400 uppercase tracking-widest font-semibold">Remaining Budget Pool</div>
          <div
            className={`text-3xl font-extrabold mt-1.5 ${
              totalBudgeted - totalSpent >= 0 ? 'text-emerald-400' : 'text-rose-500'
            }`}
          >
            {formatCurrency(totalBudgeted - totalSpent, currency)}
          </div>
        </div>
      </div>

      {/* Category Budget Target Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {expenseCategories.map((cat) => {
          const spent = categorySpentMap[cat.id] || 0;
          const limit = editingBudgets[cat.id] || 0;
          const percent = limit > 0 ? Math.round((spent / limit) * 100) : spent > 0 ? 100 : 0;

          return (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gradient-to-br from-[#12141C] to-[#0A0C12] border border-white/10 p-6 rounded-[32px] shadow-xl hover:border-white/20 transition-all"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3.5">
                  <CategoryIcon iconName={cat.iconName} color={cat.color} size={22} />
                  <div>
                    <h3 className="text-sm font-bold text-white">
                      {translate(cat.nameKey, language)}
                    </h3>
                    <div className="text-[11px] text-slate-400 mt-0.5 font-mono">
                      Spent: <span className="font-bold text-slate-200">{formatCurrency(spent, currency)}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <span
                    className={`text-xs font-bold px-3 py-1 rounded-full border ${
                      percent >= 100
                        ? 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                        : percent >= 80
                        ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                        : 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20'
                    }`}
                  >
                    {percent}% Consumed
                  </span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-2 bg-white/5 rounded-full overflow-hidden mb-4 border border-white/5">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    percent >= 100 ? 'bg-rose-500' : percent >= 80 ? 'bg-amber-500' : 'bg-indigo-500'
                  }`}
                  style={{ width: `${Math.min(100, percent)}%` }}
                ></div>
              </div>

              {/* Limit Input Control */}
              <div className="flex items-center justify-between pt-3 border-t border-white/5">
                <label className="text-xs text-slate-400 font-semibold">Monthly Target Cap ($ USD)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    step="50"
                    min="0"
                    value={limit}
                    onChange={(e) => handleBudgetChange(cat.id, parseFloat(e.target.value) || 0)}
                    className="w-28 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 text-xs text-slate-100 font-bold font-mono text-right focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
