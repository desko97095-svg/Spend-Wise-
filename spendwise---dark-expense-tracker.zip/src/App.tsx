import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Navbar } from './components/Navbar';
import { DashboardOverview } from './components/DashboardOverview';
import { TransactionList } from './components/TransactionList';
import { BudgetManager } from './components/BudgetManager';
import { MonthlyReportView } from './components/MonthlyReportView';
import { AnalyticsCharts } from './components/AnalyticsCharts';
import { AuthModal } from './components/AuthModal';
import { TransactionModal } from './components/TransactionModal';
import { UserSettingsModal } from './components/UserSettingsModal';
import { Transaction, CategoryId, CurrencyCode, LanguageCode, UserProfile, TransactionType } from './types';
import { DEFAULT_USER, INITIAL_CATEGORY_BUDGETS, INITIAL_TRANSACTIONS } from './data/defaultData';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'transactions' | 'budgets' | 'analytics' | 'ai_reports'>('dashboard');

  // Persistence State
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('spendwise_user');
    if (!saved) return null;
    try {
      const parsed = JSON.parse(saved);
      if (parsed?.name?.includes('Alex')) {
        localStorage.removeItem('spendwise_user');
        return null;
      }
      return parsed;
    } catch {
      return null;
    }
  });

  const [currency, setCurrency] = useState<CurrencyCode>(() => {
    return (localStorage.getItem('spendwise_currency') as CurrencyCode) || 'USD';
  });

  const [language, setLanguage] = useState<LanguageCode>(() => {
    return (localStorage.getItem('spendwise_language') as LanguageCode) || 'en';
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    // Clear legacy sample data if present to ensure clean slate
    if (!localStorage.getItem('spendwise_v3_empty')) {
      localStorage.removeItem('spendwise_transactions');
      localStorage.removeItem('spendwise_budgets');
      localStorage.setItem('spendwise_v3_empty', 'true');
      return [];
    }
    const saved = localStorage.getItem('spendwise_transactions');
    return saved ? JSON.parse(saved) : INITIAL_TRANSACTIONS;
  });

  const [categoryBudgets, setCategoryBudgets] = useState<Record<CategoryId, number>>(() => {
    const saved = localStorage.getItem('spendwise_budgets');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORY_BUDGETS;
  });

  // Modal States
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [initialModalType, setInitialModalType] = useState<TransactionType>('expense');
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    if (user) localStorage.setItem('spendwise_user', JSON.stringify(user));
    else localStorage.removeItem('spendwise_user');
  }, [user]);

  useEffect(() => {
    localStorage.setItem('spendwise_currency', currency);
  }, [currency]);

  useEffect(() => {
    localStorage.setItem('spendwise_language', language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem('spendwise_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('spendwise_budgets', JSON.stringify(categoryBudgets));
  }, [categoryBudgets]);

  // Handlers
  const handleOpenAddModal = (type: TransactionType = 'expense') => {
    setEditingTx(null);
    setInitialModalType(type);
    setIsTransactionModalOpen(true);
  };

  const handleEditTx = (tx: Transaction) => {
    setEditingTx(tx);
    setIsTransactionModalOpen(true);
  };

  const handleDeleteTx = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const handleSaveTransaction = (txData: Omit<Transaction, 'id'>, editId?: string) => {
    if (editId) {
      setTransactions((prev) => prev.map((t) => (t.id === editId ? { ...txData, id: editId } : t)));
    } else {
      const newTx: Transaction = {
        ...txData,
        id: `tx_${Date.now()}`,
      };
      setTransactions((prev) => [newTx, ...prev]);
    }
  };

  const handleResetData = () => {
    setTransactions(INITIAL_TRANSACTIONS);
    setCategoryBudgets(INITIAL_CATEGORY_BUDGETS);
  };

  return (
    <div className="min-h-screen bg-[#09090B] text-slate-50 font-sans selection:bg-indigo-500/30 flex flex-col">
      {/* App Top Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currency={currency}
        setCurrency={setCurrency}
        language={language}
        setLanguage={setLanguage}
        user={user}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenAddModal={() => handleOpenAddModal('expense')}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 pt-5 pb-28">
        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.18 }}
            >
              <DashboardOverview
                transactions={transactions}
                categoryBudgets={categoryBudgets}
                currency={currency}
                language={language}
                user={user}
                onNavigateToTab={(tab) => setActiveTab(tab)}
                onOpenAddModal={handleOpenAddModal}
                onOpenReportModal={() => setActiveTab('ai_reports')}
              />
            </motion.div>
          )}

          {activeTab === 'transactions' && (
            <motion.div
              key="transactions"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.18 }}
            >
              <TransactionList
                transactions={transactions}
                currency={currency}
                language={language}
                onOpenAddModal={handleOpenAddModal}
                onEditTransaction={handleEditTx}
                onDeleteTransaction={handleDeleteTx}
              />
            </motion.div>
          )}

          {activeTab === 'budgets' && (
            <motion.div
              key="budgets"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.18 }}
            >
              <BudgetManager
                categoryBudgets={categoryBudgets}
                onUpdateBudgets={setCategoryBudgets}
                transactions={transactions}
                currency={currency}
                language={language}
              />
            </motion.div>
          )}

          {activeTab === 'analytics' && (
            <motion.div
              key="analytics"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.18 }}
            >
              <AnalyticsCharts transactions={transactions} currency={currency} language={language} />
            </motion.div>
          )}

          {activeTab === 'ai_reports' && (
            <motion.div
              key="ai_reports"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.18 }}
            >
              <MonthlyReportView
                transactions={transactions}
                categoryBudgets={categoryBudgets}
                currency={currency}
                language={language}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Mobile Bottom Sheet Modals */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        user={user}
        onLogin={(newUser) => setUser(newUser)}
        onLogout={() => setUser(null)}
        language={language}
      />

      <TransactionModal
        isOpen={isTransactionModalOpen}
        onClose={() => setIsTransactionModalOpen(false)}
        onSave={handleSaveTransaction}
        initialType={initialModalType}
        editingTransaction={editingTx}
        language={language}
      />

      <UserSettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        currency={currency}
        setCurrency={setCurrency}
        language={language}
        setLanguage={setLanguage}
        user={user}
        onResetData={handleResetData}
      />
    </div>
  );
}

