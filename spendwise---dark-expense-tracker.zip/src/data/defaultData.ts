import { CategoryDef, CategoryId, Transaction, UserProfile } from '../types';

export const CATEGORIES: CategoryDef[] = [
  { id: 'housing', nameKey: 'housing', iconName: 'Home', color: 'emerald', type: 'expense' },
  { id: 'food', nameKey: 'food', iconName: 'Utensils', color: 'amber', type: 'expense' },
  { id: 'transport', nameKey: 'transport', iconName: 'Car', color: 'blue', type: 'expense' },
  { id: 'tech', nameKey: 'tech', iconName: 'Laptop', color: 'cyan', type: 'expense' },
  { id: 'entertainment', nameKey: 'entertainment', iconName: 'Tv', color: 'purple', type: 'expense' },
  { id: 'shopping', nameKey: 'shopping', iconName: 'ShoppingBag', color: 'pink', type: 'expense' },
  { id: 'utilities', nameKey: 'utilities', iconName: 'Zap', color: 'orange', type: 'expense' },
  { id: 'health', nameKey: 'health', iconName: 'HeartPulse', color: 'rose', type: 'expense' },
  { id: 'travel', nameKey: 'travel', iconName: 'Plane', color: 'indigo', type: 'expense' },
  { id: 'investments', nameKey: 'investments', iconName: 'TrendingUp', color: 'teal', type: 'expense' },
  { id: 'salary', nameKey: 'salary', iconName: 'Briefcase', color: 'emerald', type: 'income' },
  { id: 'freelance', nameKey: 'freelance', iconName: 'Code', color: 'indigo', type: 'income' },
  { id: 'other', nameKey: 'other', iconName: 'MoreHorizontal', color: 'gray', type: 'expense' },
];

export const DEFAULT_USER: UserProfile | null = null;

export const INITIAL_CATEGORY_BUDGETS: Record<CategoryId, number> = {
  housing: 0,
  food: 0,
  transport: 0,
  tech: 0,
  entertainment: 0,
  shopping: 0,
  utilities: 0,
  health: 0,
  travel: 0,
  investments: 0,
  salary: 0,
  freelance: 0,
  other: 0,
};

export const INITIAL_TRANSACTIONS: Transaction[] = [];
