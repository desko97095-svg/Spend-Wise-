import { CurrencyCode, CurrencyConfig } from '../types';

export const CURRENCIES: Record<CurrencyCode, CurrencyConfig> = {
  USD: { code: 'USD', symbol: '$', name: 'US Dollar', rate: 1.0, flag: '🇺🇸' },
  EUR: { code: 'EUR', symbol: '€', name: 'Euro', rate: 0.92, flag: '🇪🇺' },
  GBP: { code: 'GBP', symbol: '£', name: 'British Pound', rate: 0.79, flag: '🇬🇧' },
  JPY: { code: 'JPY', symbol: '¥', name: 'Japanese Yen', rate: 155.4, flag: '🇯🇵' },
  CAD: { code: 'CAD', symbol: 'CA$', name: 'Canadian Dollar', rate: 1.37, flag: '🇨🇦' },
  AUD: { code: 'AUD', symbol: 'A$', name: 'Australian Dollar', rate: 1.52, flag: '🇦🇺' },
  INR: { code: 'INR', symbol: '₹', name: 'Indian Rupee', rate: 83.9, flag: '🇮🇳' },
  CHF: { code: 'CHF', symbol: 'Fr.', name: 'Swiss Franc', rate: 0.88, flag: '🇨🇭' },
  BRL: { code: 'BRL', symbol: 'R$', name: 'Brazilian Real', rate: 5.65, flag: '🇧🇷' },
  AED: { code: 'AED', symbol: 'AED', name: 'UAE Dirham', rate: 3.67, flag: '🇦🇪' },
};

/**
 * Format base amount (in USD) to specified currency string
 */
export function formatCurrency(amountUSD: number, currencyCode: CurrencyCode = 'USD'): string {
  const config = CURRENCIES[currencyCode] || CURRENCIES.USD;
  const converted = amountUSD * config.rate;
  
  // JPY and INR formatting
  if (currencyCode === 'JPY') {
    return `${config.symbol}${Math.round(converted).toLocaleString()}`;
  }
  
  return `${config.symbol}${converted.toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function convertAmount(amountUSD: number, targetCurrency: CurrencyCode = 'USD'): number {
  const config = CURRENCIES[targetCurrency] || CURRENCIES.USD;
  return amountUSD * config.rate;
}

export function convertToUSD(amountInCurrency: number, sourceCurrency: CurrencyCode = 'USD'): number {
  const config = CURRENCIES[sourceCurrency] || CURRENCIES.USD;
  return amountInCurrency / config.rate;
}
