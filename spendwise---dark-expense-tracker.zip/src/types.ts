export type TransactionType = 'expense' | 'income';

export type CategoryId = 
  | 'housing'
  | 'food'
  | 'transport'
  | 'entertainment'
  | 'tech'
  | 'health'
  | 'shopping'
  | 'utilities'
  | 'travel'
  | 'investments'
  | 'salary'
  | 'freelance'
  | 'other';

export interface CategoryDef {
  id: CategoryId;
  nameKey: string;
  iconName: string;
  color: string;
  type: TransactionType;
}

export type PaymentMethod = 'credit_card' | 'debit_card' | 'bank_transfer' | 'apple_pay' | 'google_pay' | 'cash';

export interface Transaction {
  id: string;
  title: string;
  amount: number; // Stored in base currency USD
  type: TransactionType;
  category: CategoryId;
  date: string; // YYYY-MM-DD
  paymentMethod: PaymentMethod;
  notes?: string;
  tags?: string[];
  isRecurring?: boolean;
  receiptUrl?: string;
}

export interface CategoryBudget {
  categoryId: CategoryId;
  limitAmount: number; // In base currency USD
}

export interface MonthlyBudgetConfig {
  month: string; // YYYY-MM
  overallTarget: number;
  categoryBudgets: Record<CategoryId, number>;
}

export interface UserProfile {
  id: string;
  firstName?: string;
  lastName?: string;
  name: string;
  email: string;
  avatarUrl?: string;
  provider: 'google' | 'apple' | 'email' | 'demo';
  preferredCurrency: string; // USD, EUR, etc.
  preferredLanguage: string; // en, es, fr, etc.
  monthlyBudgetGoal: number;
  emailNotificationsEnabled: boolean;
}

export interface AIReportData {
  month: string;
  generatedAt: string;
  healthScore: number; // 0-100
  summary: string;
  keyInsights: Array<{
    type: 'positive' | 'warning' | 'alert' | 'info';
    title: string;
    description: string;
  }>;
  categoryBreakdown: Array<{
    category: CategoryId;
    spent: number;
    budgeted: number;
    variancePercent: number;
    status: 'under' | 'warning' | 'over';
  }>;
  savingsOpportunity: {
    potentialSavings: number;
    topWasteArea: string;
    actionableTips: string[];
  };
  forecastNextMonth: {
    estimatedExpense: number;
    suggestedAdjustments: Array<{
      category: CategoryId;
      recommendedLimit: number;
      reason: string;
    }>;
  };
}

export type CurrencyCode = 'USD' | 'EUR' | 'GBP' | 'JPY' | 'CAD' | 'AUD' | 'INR' | 'CHF' | 'BRL' | 'AED';

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  name: string;
  rate: number; // Rate relative to 1 USD
  flag: string;
}

export type LanguageCode = 'en' | 'es' | 'fr' | 'de' | 'ja' | 'hi' | 'zh' | 'pt' | 'ar';
